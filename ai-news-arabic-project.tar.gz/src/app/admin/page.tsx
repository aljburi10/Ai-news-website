import Link from 'next/link';

export default function AdminDashboard() {
  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">لوحة تحكم المسؤول</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* إدارة المصادر */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">إدارة المصادر</h2>
            <p className="text-gray-600 mb-4">
              إضافة وتحرير وتعطيل مصادر الأخبار. يمكنك تحديد RSS feeds لمواقع الأخبار التي ترغب في تجميع المحتوى منها.
            </p>
            <Link 
              href="/admin/sources"
              className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition"
            >
              إدارة المصادر
            </Link>
          </div>
          
          {/* إدارة الأخبار المميزة */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">إدارة الأخبار المميزة</h2>
            <p className="text-gray-600 mb-4">
              اختيار الأخبار التي تظهر في قسم "الأخبار المميزة" في الصفحة الرئيسية.
            </p>
            <Link 
              href="/admin/featured"
              className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition"
            >
              إدارة الأخبار المميزة
            </Link>
          </div>
          
          {/* إدارة التصنيفات */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">إدارة التصنيفات</h2>
            <p className="text-gray-600 mb-4">
              إضافة وتحرير وتعطيل تصنيفات الأخبار. يساعد التصنيف الجيد في تنظيم المحتوى وتحسين تجربة المستخدم.
            </p>
            <Link 
              href="/admin/categories"
              className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition"
            >
              إدارة التصنيفات
            </Link>
          </div>
          
          {/* إحصائيات الموقع */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">إحصائيات الموقع</h2>
            <p className="text-gray-600 mb-4">
              عرض إحصائيات حول عدد الأخبار والمصادر وحركة المرور على الموقع.
            </p>
            <Link 
              href="/admin/stats"
              className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition"
            >
              عرض الإحصائيات
            </Link>
          </div>
        </div>
        
        {/* تحديث الأخبار يدويًا */}
        <div className="mt-10 bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">تحديث الأخبار يدويًا</h2>
          <p className="text-gray-600 mb-4">
            يتم تحديث الأخبار تلقائيًا كل ساعة، ولكن يمكنك تشغيل التحديث يدويًا إذا كنت ترغب في ذلك.
          </p>
          <button
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition"
          >
            تحديث الأخبار الآن
          </button>
          <p className="text-sm text-gray-500 mt-2">
            آخر تحديث: لم يتم التحديث بعد
          </p>
        </div>
      </div>
    </div>
  );
}
