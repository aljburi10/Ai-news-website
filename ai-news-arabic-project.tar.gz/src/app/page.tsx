import FeaturedNews from './components/news/FeaturedNews';
import CategoryFilter from './components/news/CategoryFilter';
import NewsList from './components/news/NewsList';
import AdBanner from './components/ads/AdBanner';

export default function Home() {
  return (
    <div>
      {/* الشريط الإعلاني العلوي */}
      <AdBanner slot="1234567890" format="horizontal" className="mb-8" />
      
      {/* الأخبار المميزة */}
      <FeaturedNews />
      
      {/* تصفية التصنيفات */}
      <CategoryFilter />
      
      {/* شريط إعلاني قبل القائمة الرئيسية */}
      <AdBanner slot="2345678901" format="rectangle" className="mx-auto my-8" />
      
      {/* قائمة الأخبار الرئيسية */}
      <NewsList />
    </div>
  );
}