// إعداد القالب الأساسي لـ Cloudflare Worker
// هذا ملف مؤقت وسيتم استبداله عند النشر

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request))
})

async function handleRequest(request) {
  return new Response("مرحباً بك في موقع أخبار الذكاء الاصطناعي! الموقع قيد التطوير...", {
    headers: { 'content-type': 'text/plain;charset=UTF-8' },
  })
}
