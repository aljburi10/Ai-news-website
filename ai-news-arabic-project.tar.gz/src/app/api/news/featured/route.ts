import { NextRequest, NextResponse } from 'next/server';
import { Env } from '../../../../types';

export async function GET(request: Request, { env }: { env: Env }) {
  try {
    // الحصول على الأخبار المميزة
    const featuredQuery = `
      SELECT 
        n.id, n.title, n.slug, n.summary, n.image_url, 
        s.name as source_name, n.published_at
      FROM news n
      JOIN sources s ON n.source_id = s.id
      WHERE n.is_featured = 1
      ORDER BY n.published_at DESC
      LIMIT 4
    `;
    
    const featuredStmt = env.DB.prepare(featuredQuery);
    const featuredResult = await featuredStmt.all();
    
    // إذا لم تكن هناك أخبار مميزة كافية، أحضر أحدث الأخبار
    if (!featuredResult.results || featuredResult.results.length < 4) {
      const latestQuery = `
        SELECT 
          n.id, n.title, n.slug, n.summary, n.image_url, 
          s.name as source_name, n.published_at
        FROM news n
        JOIN sources s ON n.source_id = s.id
        WHERE n.is_featured = 0
        ORDER BY n.published_at DESC
        LIMIT ?
      `;
      
      const remainingCount = 4 - (featuredResult.results?.length || 0);
      const latestStmt = env.DB.prepare(latestQuery);
      latestStmt.bind(remainingCount);
      const latestResult = await latestStmt.all();
      
      // دمج النتائج
      const combinedResults = [
        ...(featuredResult.results || []),
        ...(latestResult.results || [])
      ];
      
      return NextResponse.json(combinedResults);
    }
    
    return NextResponse.json(featuredResult.results);
    
  } catch (error: any) {
    console.error('API Error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب الأخبار المميزة' },
      { status: 500 }
    );
  }
}
