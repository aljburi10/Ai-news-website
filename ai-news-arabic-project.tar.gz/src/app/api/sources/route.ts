import { NextRequest, NextResponse } from 'next/server';
import { Env } from '../../../types';

export async function GET(request: Request, { env }: { env: Env }) {
  try {
    // الحصول على كل المصادر
    const query = `SELECT * FROM sources ORDER BY name ASC`;
    const stmt = env.DB.prepare(query);
    const result = await stmt.all();
    
    return NextResponse.json(result.results);
  } catch (error: any) {
    console.error('API Error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب المصادر' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request, { env }: { env: Env }) {
  try {
    // استخراج بيانات المصدر الجديد
    const data = await request.json();
    const { name, url, feed_url, is_active } = data;
    
    // التحقق من البيانات
    if (!name || !url || !feed_url) {
      return NextResponse.json(
        { error: 'جميع الحقول مطلوبة' },
        { status: 400 }
      );
    }
    
    // التحقق مما إذا كان المصدر موجودًا بالفعل
    const checkStmt = env.DB.prepare(`SELECT id FROM sources WHERE name = ? OR feed_url = ?`);
    checkStmt.bind(name, feed_url);
    const existingSource = await checkStmt.first();
    
    if (existingSource) {
      return NextResponse.json(
        { error: 'المصدر موجود بالفعل' },
        { status: 409 }
      );
    }
    
    // إدراج المصدر الجديد
    const insertStmt = env.DB.prepare(`
      INSERT INTO sources (name, url, feed_url, is_active, created_at)
      VALUES (?, ?, ?, ?, datetime('now'))
    `);
    
    insertStmt.bind(
      name,
      url,
      feed_url,
      is_active !== undefined ? is_active : 1
    );
    
    const result = await insertStmt.run();
    
    if (!result.success) {
      throw new Error('فشل في إضافة المصدر');
    }
    
    // الحصول على المصدر المُدرج
    const getStmt = env.DB.prepare(`SELECT * FROM sources WHERE rowid = ?`);
    getStmt.bind(result.meta?.last_row_id);
    const newSource = await getStmt.first();
    
    return NextResponse.json(newSource, { status: 201 });
    
  } catch (error: any) {
    console.error('API Error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إضافة المصدر' },
      { status: 500 }
    );
  }
}
