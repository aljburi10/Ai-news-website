import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { formatDistanceToNow } from 'date-fns';
import { arSA } from 'date-fns/locale';
import AdBanner from '../../components/ads/AdBanner';
import { Env } from '../../../types';

// التحقق صحة عنوان URL
export async function generateMetadata({ params }: { params: { slug: string } }) {
  const news = await getNewsItem(params.slug);
  
  if (!news) {
    return {
      title: 'الخبر غير موجود',
      description: 'الصفحة المطلوبة غير موجودة',
    };
  }
  
  return {
    title: news.title,
    description: news.summary,
    openGraph: {
      title: news.title,
      description: news.summary,
      images: news.image_url ? [news.image_url] : undefined,
    },
  };
}

// دالة للحصول على الخبر من قاعدة البيانات
async function getNewsItem(slug: string) {
  try {
    // هنا يتم الوصول إلى قاعدة البيانات D1 
    // في البيئة الحقيقية، سيتم استخدام env.DB بدلاً من هذا النموذج
    
    // هذا يعمل كمثال لشكل البيانات، ولكن في البيئة الحقيقية سيتم استبداله
    // بالاستعلام الفعلي من قاعدة البيانات D1 في Cloudflare
    const mockNewsItem = {
      id: 1,
      title: 'ChatGPT يتعلم التحدث باللهجات العربية المختلفة',
      slug: 'chatgpt-learns-arabic-dialects',
      content: 'أعلنت شركة OpenAI عن تحديث جديد لنموذج ChatGPT يمكنه الآن من التحدث والتفاعل بمختلف اللهجات العربية بما في ذلك المصرية والخليجية والشامية والمغاربية. يأتي هذا التطور بعد أشهر من العمل على تحسين قدرات النموذج اللغوية وفهمه للتنوع اللغوي في المنطقة العربية. وقال سام ألتمان، الرئيس التنفيذي للشركة، إن هذه الخطوة تأتي استجابة للطلب المتزايد من المستخدمين العرب وتعكس التزام الشركة بتطوير تقنيات ذكاء اصطناعي أكثر شمولاً وتنوعاً. وأضاف أن الفريق استعان بخبراء لغويين من مختلف أنحاء العالم العربي لضمان دقة النموذج وقدرته على فهم الفروق الدقيقة بين اللهجات المختلفة.',
      summary: 'أعلنت OpenAI عن تحديث يمكن ChatGPT من التحدث بمختلف اللهجات العربية مثل المصرية والخليجية والشامية والمغاربية.',
      image_url: 'https://placehold.co/800x450?text=ChatGPT+واللهجات+العربية',
      source_name: 'تك عربية',
      category_name: 'تطبيقات الذكاء الاصطناعي',
      published_at: '2024-04-01T10:30:00.000Z',
      created_at: '2024-04-01T11:00:00.000Z',
    };
    
    return mockNewsItem;
    
  } catch (error) {
    console.error('Error fetching news:', error);
    return null;
  }
}

// دالة للحصول على أخبار ذات صلة
async function getRelatedNews(categoryId: number, currentNewsId: number) {
  try {
    // في البيئة الحقيقية، سيتم استبدال هذا بالاستعلام الفعلي
    const mockRelatedNews = [
      {
        id: 2,
        title: 'جوجل تطلق نموذج Gemini باللغة العربية',
        slug: 'google-launches-gemini-in-arabic',
        summary: 'أعلنت شركة جوجل عن إطلاق نموذج Gemini بدعم كامل للغة العربية، مما يتيح للمستخدمين العرب الاستفادة من قدرات الذكاء الاصطناعي المتقدمة.',
        image_url: 'https://placehold.co/400x300?text=Gemini+باللغة+العربية',
        published_at: '2024-03-25T14:20:00.000Z',
      },
      {
        id: 3,
        title: 'مايكروسوفت تطلق Copilot للمستخدمين العرب',
        slug: 'microsoft-copilot-for-arabic-users',
        summary: 'أطلقت مايكروسوفت مساعدها الذكي Copilot للمستخدمين الناطقين بالعربية مع دعم محسن للغة العربية وفهم أفضل للسياق الثقافي.',
        image_url: 'https://placehold.co/400x300?text=Copilot+للمستخدمين+العرب',
        published_at: '2024-03-30T09:15:00.000Z',
      }
    ];
    
    return mockRelatedNews;
    
  } catch (error) {
    console.error('Error fetching related news:', error);
    return [];
  }
}

export default async function NewsDetail({ params }: { params: { slug: string } }) {
  const news = await getNewsItem(params.slug);
  
  if (!news) {
    notFound();
  }
  
  const relatedNews = await getRelatedNews(1, news.id);
  const formattedDate = formatDistanceToNow(new Date(news.published_at), {
    addSuffix: true,
    locale: arSA,
  });
  
  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        {/* شريط إعلاني علوي */}
        <AdBanner slot="1234567890" format="horizontal" className="mb-8" />
        
        <article className="bg-white rounded-lg shadow-md overflow-hidden">
          {/* رأس المقال */}
          <div className="p-6 pb-0">
            <div className="flex items-center text-sm text-gray-500 mb-2">
              <Link href={`/?category=${encodeURIComponent(news.category_name)}`} className="bg-indigo-100 text-indigo-800 px-2 py-1 rounded">
                {news.category_name}
              </Link>
              <span className="mx-2">•</span>
              <span>{news.source_name}</span>
              <span className="mx-2">•</span>
              <span>{formattedDate}</span>
            </div>
            
            <h1 className="text-3xl font-bold mb-4">{news.title}</h1>
          </div>
          
          {/* صورة الخبر */}
          <div className="relative h-80 md:h-96 w-full my-6">
            <Image
              src={news.image_url || 'https://placehold.co/1200x600?text=أخبار+الذكاء+الاصطناعي'}
              alt={news.title}
              fill
              style={{ objectFit: 'cover' }}
            />
          </div>
          
          {/* محتوى المقال */}
          <div className="p-6">
            <div className="prose max-w-none prose-lg prose-indigo mb-8">
              {/* طباعة المحتوى فقرة تلو الأخرى */}
              {news.content.split('\n').map((paragraph, index) => (
                <p key={index} className="mb-4">{paragraph}</p>
              ))}
            </div>
            
            {/* مشاركة المقال */}
            <div className="border-t border-b border-gray-200 py-4 my-6">
              <div className="flex justify-between items-center">
                <span className="font-semibold">مشاركة المقال:</span>
                <div className="flex space-x-4 rtl:space-x-reverse">
                  <button className="text-blue-600 hover:text-blue-800">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" />
                    </svg>
                  </button>
                  <button className="text-blue-900 hover:text-blue-700">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z" />
                    </svg>
                  </button>
                  <button className="text-green-600 hover:text-green-800">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" />
                    </svg>
                  </button>
                  <button className="text-indigo-600 hover:text-indigo-800">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M7.127 22.562l-7.127 1.438 1.438-7.128 5.689 5.69zm1.414-1.414l11.228-11.225-5.69-5.692-11.227 11.227 5.689 5.69zm9.768-21.148l-2.816 2.817 5.691 5.691 2.816-2.819-5.691-5.689z" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </article>
        
        {/* إعلان في المنتصف */}
        <div className="my-8">
          <AdBanner slot="2345678901" format="rectangle" className="mx-auto" />
        </div>
        
        {/* أخبار ذات صلة */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">أخبار ذات صلة</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedNews.map((relatedItem) => (
              <div key={relatedItem.id} className="news-card bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative aspect-video">
                  <Image
                    src={relatedItem.image_url || 'https://placehold.co/400x300?text=أخبار+الذكاء+الاصطناعي'}
                    alt={relatedItem.title}
                    fill
                    style={{ objectFit: 'cover' }}
                  />
                </div>
                
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2 line-clamp-2 hover:text-indigo-600">
                    <Link href={`/news/${relatedItem.slug}`}>
                      {relatedItem.title}
                    </Link>
                  </h3>
                  
                  <p className="text-gray-600 mb-4 text-sm line-clamp-2">
                    {relatedItem.summary}
                  </p>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(relatedItem.published_at), {
                        addSuffix: true,
                        locale: arSA,
                      })}
                    </span>
                    <Link
                      href={`/news/${relatedItem.slug}`}
                      className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                    >
                      اقرأ المزيد
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}