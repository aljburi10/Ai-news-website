import { NextRequest, NextResponse } from 'next/server';
import { Env } from '../../../types';

export async function GET(request: Request, { env }: { env: Env }) {
  try {
    // الحصول على كل التصنيفات
    const query = `SELECT * FROM categories ORDER BY name ASC`;
    const stmt = env.DB.prepare(query);
    const result = await stmt.all();
    
    return NextResponse.json(result.results);
  } catch (error: any) {
    console.error('API Error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب التصنيفات' },
      { status: 500 }
    );
  }
}
